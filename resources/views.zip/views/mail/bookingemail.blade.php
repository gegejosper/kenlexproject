<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
                            <div class="col-md-8 col-md-offset-2">
                                <div class="help-block">
                                <h2 class="text-center">Thank You for your Booking</h2>
                               <p>We will contact you for final confirmation</p>

                                </div>
                               
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>