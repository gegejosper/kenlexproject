<?php $__env->startSection('content'); ?>
 <div class="main">
  <div class="main-inner">
    <div class="container">
        <div class="row">
            <div class="span12">
                <div class="widget-content">
                <?php $__currentLoopData = $dataPackage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p>Package Name: <strong> <?php echo e($Package->package->packagename); ?> </strong></p>
                <p>Description: <strong> <?php echo e($Package->package->description); ?> </strong></p>
                <p>Package Price: <strong> <?php echo e($Package->price); ?> </strong></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div style="padding-top:20px;"></div>
      <div class="row">
        <!-- /span4 -->
        <div class="span8">
        <div class="widget widget-table action-table">
            <div class="widget-header"> <i class="icon-sitemap"></i>
              <h3>Products</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
            <table class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>Product Picture </th>
                    <th>Product Name</th>
                    <th>Package Quantity</th>
                    <th>Quantity</th>
                    <th>Status</th>
                    <th class="td-actions"> Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php  $avail = 0;?>
                  <?php $__currentLoopData = $dataArrayPackageItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ProductDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $ProductDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ProductDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr class="item<?php echo e($ProductDetail->id); ?>">
                      <td align="center" style="text-align:center" width="100px"> <a href="#" class="avatar"><img src="<?php echo e(asset('productimg')); ?>/<?php echo e($ProductDetail->product->pic); ?>" width="50px"/></a> </td>
                        <td style="width:100px;"><a href="/cashier/products/<?php echo e($ProductDetail->prod_id); ?>"><?php echo e($ProductDetail->product->product_name); ?></a></td>
                        <td style="width:150px;"><a href="/cashier/products/<?php echo e($ProductDetail->prod_id); ?>"><?php echo e($ProductDetail->packageitem->quantity); ?></a></td>
                        <td style="width:100px;"><a href="/cashier/products/<?php echo e($ProductDetail->prod_id); ?>"><?php echo e($ProductDetail->quantity); ?></a></td>
                        <td><?php 
                       
                         if($ProductDetail->quantity <= 0){
                           echo "Not Available";
                           $avail = 1;
                         }
                         else {
                          echo "Available";
                         }
                        ?></td>
                        <td style="width:100px;" class="td-actions"><a href="/cashier/products/<?php echo e($ProductDetail->prod_id); ?>" class="btn btn-mini btn-info"  ><i class="icon-search"> </i>View</a></td>
                        
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <tr><td colspan="5">
                  
                   <?php $__currentLoopData = $dataPackage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php if ($avail === 0) { ?>
                  
                    <a href="/cashier/packageorder/<?php echo e($Package->packageid); ?>" class="btn btn-medium btn-success" >Buy Walk-in</a> <a href="/cashier/newdealer/<?php echo e($Package->packageid); ?>" class="btn btn-medium btn-success" >Buy New Dealer</a> <a href="/cashier/dealer/<?php echo e($Package->packageid); ?>" class="btn btn-medium btn-success" >Buy Dealer</a>
                   <?php } 
                   
                   else {
                     echo "<em>Package Not Available to Purchase</em>";
                   }?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </td></tr>
                </tbody>
              </table>
            </div>
            <!-- /widget-content --> 
          </div>            

       

        </div>
        <!-- /span4 --> 
      </div>
      <!-- /row --> 

    </div>
    <!-- /container --> 
  </div>
  <!-- /main-inner --> 
</div>
<div id="myModal" class="modal fade" role="dialog">
  		<div class="modal-dialog">
  			<!-- Modal content-->
  			<div class="modal-content">
  				<div class="modal-header">
  					<button type="button" class="close" data-dismiss="modal">&times;</button>
  					<h4 class="modal-title"></h4>
  				</div>
  				<div class="modal-body">
  					<form class="form-horizontal" role="form">
                      <?php echo e(csrf_field()); ?>

  						<div class="form-group">
  							<label class="control-label col-sm-2" for="id">ID:</label>
  							<div class="col-sm-10">
  								<input type="text" class="form-control" id="fid" disabled>
  							</div>
  						</div>
  						<div class="form-group">
  							<label class="control-label col-sm-2" for="supplier_name" >Product Name:</label>
  							<div class="col-sm-10">
  								<input type="text" class="form-control" id="productedit_name" name="productedit_name">
  							</div>
                <label class="control-label col-sm-2" for="description" >Description:</label>
  							<div class="col-sm-10">
  							
                 
                  <textarea name="editdescription" id="editdescription" cols="30" rows="10"></textarea>
  							</div>
                          </div>
            
  					</form>
  					<div class="deleteContent">
  						Are you Sure you want to delete <span class="dname"></span> ? <span
  							class="hidden did"></span>
  					</div>
  					<div class="modal-footer">
  						<button type="button" class="btn actionBtn" data-dismiss="modal">
  							<span id="footer_action_button" class='glyphicon'> </span>
  						</button>
  						<button type="button" class="btn btn-warning" data-dismiss="modal">
  							<span class='glyphicon glyphicon-remove'></span> Close
  						</button>
  					</div>
  				</div>
  			</div>
		  </div>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
    </div>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/branchpackagescript.js')); ?>"></script>
<!-- /main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cashier.layouts.cashier', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>