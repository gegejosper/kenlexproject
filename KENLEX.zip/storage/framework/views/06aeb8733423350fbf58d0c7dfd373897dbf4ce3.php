<?php $__env->startSection('content'); ?>
 <div class="main">
  <div class="main-inner">
    <div class="container">
   
      <div class="row">
      <div class="span6">
      <div align="center" style="padding:20px 0px;"><img src="<?php echo e(asset('img/logohorizontal.png')); ?>" align="center"></div>
            <div class="widget">	
                        <div class="widget-header">
                            <h3>Order Code : <?php echo e($orderCode); ?></h3>
                        </div> <!-- /widget-header -->
                        <div class="widget-content">
                <table class="table table-striped table-bordered" id="table">
                    <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Amount</th>
                        <th>Quantity </th>
                    
                    </tr>
                    </thead>
                    <tbody>
                
                    <?php $amount =0; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $dataReqorder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="item<?php echo e($order->item_id); ?>">
                        <td width="250px"> <a href="/product/<?php echo e($order->item_id); ?>" class="name">
                        
                        <?php echo e($order->product_name); ?>

                        </a> </td>
                        <td><?php echo e($order->ramount); ?></td>
                        <td><?php echo e($order->rquantity); ?></td>
                    
            
                    </td>
                    </tr>
                    <?php $amount = $amount + $order->ramount; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4">No Data</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                <h5>Status : <?php 
                                    if($order->status == 0) {
                                      echo "Waiting for Approval";
                                    }
                                    elseif($order->status == 1) {
                                        echo "Approved";
                                    }
                                    elseif($order->status == 2) {
                                        echo "Disapproved";
                                    }
                                    elseif($order->status == 3) {
                                      echo "Canceled";
                                  }
                                    else {
                                        echo "Unidentified";
                                    }
                                  ?>  </h5>
                <h5>Total Amount :Php <?php echo e(number_format($amount, 2)); ?></h5> <br>
                <button class="btn btn-primary hidden-print noprint" align="right" onclick="myFunction()"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Print</button>
                    <script>
                    function myFunction() {
                    window.print();}
                    </script>
               
    </div>
</div>
      </div>
    
      </div>
      <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /main-inner --> 
</div>
<!-- /main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layouts.customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>