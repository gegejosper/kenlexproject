

<?php $__env->startSection('content'); ?>
 <div class="main">
  <div class="main-inner">
    <div class="container">
    <div class="row">
        <div class="span6">
            <div class="widget widget-nopad">
                <div class="widget-header"> <i class="icon-list-alt"></i>
                <h3>Add Product Basic Info</h3>
                </div>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                        <?php 
                        Session::forget('success');
                         ?>
                    </div>
                    <?php endif; ?>
                <!-- /widget-header -->
                <div class="widget-content">
                <div class="widget big-stats-container">
                    <div class="widget-content">
                    
                    <div id="big_stats" class="cf">
                        <div class="control-group padding-20">	
                      
                        <?php echo e(csrf_field()); ?>    
                            <label for="Product Name">Product Name</label>
                            <input type="text" class="form-control" placeholder="Product Name"  name="product_name">
                            <label class="control-label" for="Description">Description</label>
                                                <div class="controls">
                                                <textarea name="description" id="description" cols="50" rows="10" placeholder="Description" style="width:90%;"></textarea>			
                                                </div>
                                                <button class="btn btn-large btn-primary " type="submit" id="add" >Save</button>            
                        </div>  <!-- .stat --> 
                    </div>
                    </div>
                    <!-- /widget-content --> 
                </div>
                </div>
            </div>
        </div>
        <div class="span6">
            <div class="widget widget-nopad">
                <div class="widget-header"> <i class="icon-list-alt"></i>
                <h3>Product List</h3>
                </div>
                <!-- /widget-header -->
                <div class="widget-content">
                <div class="widget big-stats-container">
                    <div class="widget-content">
                    
                    <div id="big_stats" class="cf">
                        <div class="control-group padding-20">	
                        <table class="table table-striped table-bordered" id="table">
                <thead>
                  <tr>
                    <th>Product ID</th>
                    <th>Name</th>
                    <th> Action </th>
                  </tr>
                </thead>
                <tbody>
            
  				
                  <?php $__currentLoopData = $dataProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr class="item<?php echo e($Product->id); ?>">
                    <td style="width:100px;"><?php echo e($Product->id); ?></td>
                    <td> <a href="products/<?php echo e($Product->id); ?>" class="name"><?php echo e($Product->product_name); ?></a> </td>
                    <td style="width:100px;" class="td-actions"><a href="javascript:;" class="edit-modal btn btn-mini btn-info" data-id="<?php echo e($Product->id); ?>" data-name="<?php echo e($Product->product_name); ?>" data-description="<?php echo e($Product->description); ?>"><i class="icon-pencil"> </i></a> </td>
                    
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>          
                        </div>  <!-- .stat --> 
                    </div>
                    </div>
                    <!-- /widget-content --> 
                </div>
                </div>
            </div>
        </div>
    </div>
      <div class="row">
        <div class="span12">
            
            <div class="widget widget-table action-table">
                    <div class="widget-header"> <i class="icon-plus"></i>
                    <h3>Add Product</h3>
                    </div>
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                        <?php 
                        Session::forget('success');
                         ?>
                    </div>
                    <?php endif; ?>
                    <form enctype="multipart/form-data" action="<?php echo e(route('addproductquantity')); ?>" method="post">
                        
                        <div class="widget-content" style="padding:20px;">
                        <?php echo e(csrf_field()); ?>                                       
                          
                                <div class="span3">
                                    <div class="widget"> 
                                   
                                        <label for="Product Name">Product Image</label> 
                                        <input data-preview="#preview" name="input_img" type="file" id="imageInput" required>
                                                <img class="col-sm-6" id="preview"  src="" ></img>
                                        <label for="Product Name">Product Name</label> 
                                        <select name="prod_id" id="prod_id">
                                        <?php $__currentLoopData = $dataProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($Product->id); ?>"><?php echo e($Product->product_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label for="Brand Name">Brand</label>
                                        <select name="brand_id" id="brand_id">
                                            <?php $__currentLoopData = $dataBrand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($Brand->id); ?>"><?php echo e($Brand->brand_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="control-group">											
											<label class="control-label" for="Regular Price">Regular Price</label>
											<div class="controls">
                                            <input type="text" class="form-control" placeholder="Regular Price"  name="price">
											</div> <!-- /controls -->				
										</div>
                                        <div class="control-group">											
											<label class="control-label" for="password1">Sale Price</label>
											<div class="controls">
                                            <input type="text" class="form-control" placeholder="Sale Price"  name="saleprice">
											</div> <!-- /controls -->				
										</div> 
                                        <div class="control-group">											
											<label class="control-label">Price Option</label>
                                            <div class="controls">
                                            <label class="radio inline">
                                              <input type="radio" name="priceoption" value="regular"> Regular
                                            </label>
                                            
                                            <label class="radio inline">
                                              <input type="radio" name="priceoption" value="sale"> Sale
                                            </label><br>
                                           
                                        </div>
                                       
                                        <label for="Category">Category</label>
                                        <select name="category_id" id="category_id">
                                            <?php $__currentLoopData = $dataCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($Category->id); ?>"><?php echo e($Category->cat_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label for="Quantity">Quantity</label>
                                        <input type="text" class="form-control" placeholder="Quantity" name="quantity">    
                                        <label for="Brand Name">Unit</label>
                                        <select name="unit" id="unit">
                                                <option value="piece">piece</option>
                                                <option value="roll">roll</option>
                                                <option value="can">can</option>
                                                <option value="bottle">bottle</option>
                                                <option value="pack">pack</option>
                                                <option value="unit">unit</option>
                                                <option value="pad">pad</option>
                                                <option value="box">box</option>
                                                <option value="container">container</option>
                                                <option value="set">set</option>
                                                <option value="bundle">bundle</option>
                                                <option value="case">case </option>
                                                <option value="ream">ream</option>
                                                <option value="pair">pair</option>
                                        </select>
                                       
                                       
                                        <!-- /controls -->			
										</div> 
                                    </div> <!-- /widget -->   
                                </div>
                                <div class="span4">
                                    <div class="widget">   
                                    <label for="Supplier">Supplier</label>
                                        <select name="supplier_id" id="supplier_id">
                                            <?php $__currentLoopData = $dataSupplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($Supplier->id); ?>"><?php echo e($Supplier->supplier_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label for="Branch Name">Branch Availability</label> 
                                        <select name="branch_id" id="branch_id">
                                        <?php $__currentLoopData = $dataBranch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($Branch->id); ?>"><?php echo e($Branch->branch_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <fieldset>
                                        <legend>Optional</legend>
 
 
                                        <label>Tags:</label>
                                        <input data-role="tagsinput" type="text" name="tags" >
                                        <?php if($errors->has('tags')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('tags')); ?></span>
                                                    <?php endif; ?> 
                                            <label for="Length">Length</label> 
                                            <input type="text" class="form-control" placeholder="Length"  name="length">
                                            <label for="Width">Width</label> 
                                            <input type="text" class="form-control" placeholder="Width"  name="width">
                                            <label for="Height">Height</label> 
                                            <input type="text" class="form-control" placeholder="Height"  name="height">
                                            <label for="Weight">Weight</label> 
                                            <input type="text" class="form-control" placeholder="Weight"  name="weight">
                                    </fieldset>
                                    </div> <!-- /widget -->   
                                </div>
                                <div class="span4">
                                
                                    <div class="widget">  
                                    <div class="control-group">											
                                            <label class="control-label" for="Description">Description</label>
                                            <div class="controls">
                                            <textarea name="description" id="" cols="50" rows="20" placeholder="Description" style="width:90%;"></textarea>			
                                            </div>
                                        </div> 
                                    </div> <!-- /widget -->   
                                </div>
                                <div class="span12"><button class="btn btn-lg btn-primary " type="submit" id="add">Save</button></div>    
                                        
                        </div>
                       
                    </form>
            </div>
        </div>

        <!-- /span4 -->
        <div class="span12">
        <div class="widget widget-table action-table">
            <div class="widget-header"> <i class="icon-sitemap"></i>
              <h3>Products</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
            <table class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>Product Picture </th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Category</th>
                    <th>Tags</th>
                    <th class="td-actions"> Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $dataProductquantity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details => $Productquantity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr class="item<?php echo e($Productquantity->id); ?>">
                  <td align="center" style="text-align:center" width="100px"> <a href="#" class="avatar"><img src="<?php echo e(asset('productimg')); ?>/<?php echo e($Productquantity->pic); ?>" width="50px"/></a> </td>
                    <td style="width:100px;"><?php echo e($Productquantity->product->product_name); ?></td>
                    <td><?php echo e($Productquantity->quantity); ?></td>
                    <td><?php echo e($Productquantity->price); ?></td>
                    <td><?php echo e($Productquantity->category->cat_name); ?></td>
                    <td>
                    <?php $__currentLoopData = $Productquantity->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="label label-info"><?php echo e($tag->name); ?></label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td style="width:100px;" class="td-actions"><a href="javascript:;" class="edit-modal btn btn-mini btn-info" data-id="<?php echo e($Productquantity->id); ?>" ><i class="icon-pencil"> </i></a> </td>
                    
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <!-- /widget-content --> 
          </div>            

       

        </div>
        <!-- /span4 --> 
      </div>
      <!-- /row --> 
      <div class="row">
	      	
	      	<div class="span12">
              <div class="widget-header">
						<i class="icon-star"></i>
						<h3>Daily Sales Summary Report</h3>
					</div>
	      	<div class="info-box">
               <div class="row-fluid stats-box">
                   
                  <div class="span4">
                  	<div class="stats-box-title">Branch 1</div>
                    <div class="stats-box-all-info"><i class="icon-money" style="color:#3366cc;"></i> 555K</div>
                    
                  </div>
                  
                  <div class="span4">
                    <div class="stats-box-title">Branch 2</div>
                    <div class="stats-box-all-info"><i class="icon-money" style="color:#F30"></i> 66.66</div>
                   
                  </div>
                  
                  <div class="span4">
                    <div class="stats-box-title">Total Sales</div>
                    <div class="stats-box-all-info"><i class="icon-money" style="color:#3C3"></i> 15.55</div>
                    
                  </div>
               </div>
               
               
             </div>
               
               
         </div>
         </div>
    <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /main-inner --> 
</div>
<div id="myModal" class="modal fade" role="dialog">
  		<div class="modal-dialog">
  			<!-- Modal content-->
  			<div class="modal-content">
  				<div class="modal-header">
  					<button type="button" class="close" data-dismiss="modal">&times;</button>
  					<h4 class="modal-title"></h4>
  				</div>
  				<div class="modal-body">
  					<form class="form-horizontal" role="form">
                      <?php echo e(csrf_field()); ?>

  						<div class="form-group">
  							<label class="control-label col-sm-2" for="id">ID:</label>
  							<div class="col-sm-10">
  								<input type="text" class="form-control" id="fid" disabled>
  							</div>
  						</div>
  						<div class="form-group">
  							<label class="control-label col-sm-2" for="supplier_name" >Product Name:</label>
  							<div class="col-sm-10">
  								<input type="text" class="form-control" id="productedit_name" name="productedit_name">
  							</div>
                <label class="control-label col-sm-2" for="description" >Description:</label>
  							<div class="col-sm-10">
  							
                 
                  <textarea name="editdescription" id="editdescription" cols="30" rows="10"></textarea>
  							</div>
                          </div>
            
  					</form>
  					<div class="deleteContent">
  						Are you Sure you want to delete <span class="dname"></span> ? <span
  							class="hidden did"></span>
  					</div>
  					<div class="modal-footer">
  						<button type="button" class="btn actionBtn" data-dismiss="modal">
  							<span id="footer_action_button" class='glyphicon'> </span>
  						</button>
  						<button type="button" class="btn btn-warning" data-dismiss="modal">
  							<span class='glyphicon glyphicon-remove'></span> Close
  						</button>
  					</div>
  				</div>
  			</div>
		  </div>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
    </div>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/productscript.js')); ?>"></script>
<!-- /main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>