

<?php $__env->startSection('content'); ?>
 <div class="main">
  <div class="main-inner">
    <div class="container">
      <div class="row">
      <div class="span12">
      <table class="table table-striped table-bordered" id="table">
                <thead>
                  <tr>
                    <th>Product Name</th>
                    <th>Amount</th>
                    <th>Quantity </th>
                    <th>Action </th>
                  </tr>
                </thead>
                <tbody>
            
                <?php $amount =0; ?>
                  <?php $__empty_1 = true; $__currentLoopData = $dataReqorder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr class="item<?php echo e($order->item_id); ?>">
                    <td width="250px"> <a href="products/<?php echo e($order->item_id); ?>" class="name">
                    
                    <?php echo e($order->product_name); ?>

                    </a> </td>
                    <td><?php echo e($order->ramount); ?></td>
                    <td><?php echo e($order->rquantity); ?></td>
                    <td style="width:350px;" class="td-actions">
                    <a href="/customer/deleteorder/<?php echo e($order->item_id); ?>/<?php echo e($order->requestId); ?>" class="btn btn-danger" data-id="<?php echo e($order->item_id); ?>" data-reqid="<?php echo e($order->req_id); ?>" id="deleteproduct">
                    <i class="icon-remove"></i> <span style="color:#fff;">Cancel</span>
                    </a>
                   
                   </td>
                   </tr>
                   <?php $amount = $amount + $order->ramount; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                   <tr><td colspan="4">No Data</td></tr>
                   <?php endif; ?>
                </tbody>
    </table>
      </div>
    
      </div>
      <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /main-inner --> 
</div>
<!-- /main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layouts.customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>