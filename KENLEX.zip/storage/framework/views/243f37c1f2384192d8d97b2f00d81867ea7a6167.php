<?php $__env->startSection('content'); ?>
<div class="main">
  <div class="main-inner">
    <div class="container">
      <div class="row">
        <div class="span4 noprint">
            <div class="widget widget-table action-table noprint">
                  <div class="widget-header"> <i class="icon-th-list"></i>
                    <h3>Generate Report</h3>
                  </div>
                      <div class="widget-content">
                          <div class="box box-info">
                              <div class="box-header">
                                  <i class="fa fa-envelope"></i>
                                  <h3 class="box-title"></h3>
                              </div>
                              <form action="/admin/report/generate" method="post">
                                <?php echo e(csrf_field()); ?>   
                                <div class="box-body">
                                        <div class="form-group">
                                        <label for="">From: </label>
                                            <input type="date" class="form-control" name="from" required/>
                                        </div>
                                        <div class="form-group">
                                        <label for="">To: </label>
                                            <input type="date" class="form-control" name="to" required/>
                                        </div>
                                </div>
                                <div class="" style="padding:20px;">
                                    <button type="submit" class="pull-right btn btn-default" id="sendEmail">Generate Report <i class="fa fa-arrow-circle-right"></i></button>
                                </div>
                              </form>
                          </div> 
                          
                      </div>               
            </div>
            <div class="widget widget-table action-table noprint">
                  <div class="widget-header"> <i class="icon-th-list"></i>
                    <h3>Report by Type</h3>
                  </div>
                <div class="widget-content">
                <div class="shortcuts box-body"> 
                  <a href="/admin/report/sales" class="btn btn-info">Walk-in Sales Report</a>
                  <a href="/admin/report/dealers"class="btn btn-info">Dealers Sales Report</a>
                </div>
                </div>
                
            </div>
            <div class="widget widget-table action-table noprint">
                  <div class="widget-header"> <i class="icon-th-list"></i>
                    <h3>Report by Branch</h3>
                  </div>
                <div class="widget-content">
                    <div class="shortcuts box-body"> 
                    <?php $__currentLoopData = $dataBranch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/admin/report/branch/<?php echo e($Branch->id); ?>" class="shortcut"><i class="shortcut-icon icon-sitemap"></i><span class="shortcut-label"><?php echo e($Branch->branch_name); ?></span> </a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div><!-- /shortcuts --> 
                </div>
                
            </div>
           
        </div>
        <div class="span8">
          <div class="widget widget-table action-table">
              <div class="widget-header"> <i class="icon-th-list"></i>
                <h3>Walkin Sales Report</h3>
              </div>
            <!-- /widget-header -->
              <div class="widget-content">
                <table class="table table-striped table-bordered">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Order Number </th>
                      <th>Amount Paid</th>
                     
                      <th>Total Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php $totalamount= 0;?>
                    <?php $__currentLoopData = $reportPurchase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $totalamount = $totalamount + $Purchase->amount; ?>
                    <tr>
                    <td align="center" style="text-align:center"><?php echo e($Purchase->date); ?></td>
                      <td><?php echo e($Purchase->orderNumber); ?></a></td>
                      <td><?php echo e(number_format($Purchase->amountpaid,2)); ?></a></td>
                      
                      <td><?php echo e(number_format($Purchase->amount,2)); ?></em>  </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr><td colspan="3" align="right">Total Sales</td><td><?php echo number_format($totalamount,2); ?></td></tr>
                    <tr>
                        <td colspan="5">
                        <button class="btn btn-primary hidden-print noprint" align="right" onclick="myFunction()"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Print</button>
                        <script>
                        function myFunction() {
                        window.print();}
                        </script>
                        </td>
                    </tr>
                  </tbody>
                </table>
              </div>
          </div>
               
        </div>
        <!-- /span4 --> 
        <div class="span4"> &nbsp;</div>
        <div class="span8">
          <div class="widget widget-table action-table">
              <div class="widget-header"> <i class="icon-th-list"></i>
                <h3>Dealers Sales Report</h3>
              </div>
            <!-- /widget-header -->
              <div class="widget-content">
                <table class="table table-striped table-bordered">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Order Number </th>
                      <th>Dealer </th>
                      <th>Total Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php $totalamountDealers= 0;?>
                    <?php $__currentLoopData = $reportDealerspackageorder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Dealers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $totalamountDealers = $totalamount + $Dealers->packageprice; ?>
                    <tr>
                    <td align="center" style="text-align:center"><?php echo e($Dealers->created_at); ?></td>
                      <td><?php echo e($Dealers->ordernumber); ?></a></td>

                      <td><?php echo e($Dealers->dealer->fname); ?> <?php echo e($Dealers->dealer->lname); ?></td>
                      <td><?php echo e(number_format($Dealers->packageprice,2)); ?></em>  </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr><td colspan="3" align="right">Total Sales</td><td><?php echo number_format($totalamountDealers,2); ?></td></tr>
                    <tr>
                        <td colspan="5">
                        <button class="btn btn-primary hidden-print noprint" align="right" onclick="myFunction()"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Print</button>
                        <script>
                        function myFunction() {
                        window.print();}
                        </script>
                        </td>
                    </tr>
                  </tbody>
                </table>
              </div>
          </div>
               
        </div>
        <!-- /span4 --> 
      </div>
      <!-- /row --> 
        <div class="row noprint">
              <div class="span12">
                  <div class="widget-header">
                <i class="icon-star"></i>
                <h3>Sales Summary Report</h3>
              </div>
              <div class="info-box">
                    <div class="row-fluid stats-box">
                      <div class="span3">
                        <div class="stats-box-title">Today's Sales</div>
                        <div class="stats-box-all-info"><i class="icon-money" style="color:#3366cc;"></i> <?php echo e(number_format($DailySales,2)); ?></div>
                      </div>
                      <div class="span3">
                        <div class="stats-box-title">Monthly Sales</div>
                        <div class="stats-box-all-info"><i class="icon-money" style="color:red;"></i> <?php echo e(number_format($TotalMonthlySales,2)); ?></div>
                      </div>
                      <div class="span3">
                        <div class="stats-box-title">Yearly Sales</div>
                        <div class="stats-box-all-info"><i class="icon-money" style="color:#3C3000"></i> <?php echo e(number_format($TotalYearlySales,2)); ?></div>  
                      </div>
                      <div class="span3">
                        <div class="stats-box-title">Total Sales</div>
                        <div class="stats-box-all-info"><i class="icon-money" style="color:#3C3"></i> <?php echo e(number_format($TotalSales,2)); ?></div>  
                      </div>
                    </div>
                </div>
        </div>
    </div>
    <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /main-inner --> 
</div>
<!-- /main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>