<?php $__env->startSection('content'); ?>
 <div class="main">
  <div class="main-inner">
    <div class="container">
      <div class="row">
        <div class="span4">
          <div class="widget widget-table action-table">
            <div class="widget-header"> <i class="icon-th"></i>
              <h3>Stocks</h3>
              <div style="float:right; padding-right:10px;"></div>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
            <table class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>  </th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $dataProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                  <td align="center" style="text-align:center"><img src="<?php echo e(asset('productimg')); ?>/<?php echo e($Product->pic); ?>" width="30px"/></td>
                    <td><?php echo e($Product->product_name); ?></td>
                    <td><em class="productprice"><?php echo e($Product->warehousequantity); ?></em>  </td>
                    <td style="width:100px;" class="td-actions"><a href="javascript:;" class="edit-modal btn btn-mini btn-info" data-id="<?php echo e($Product->id); ?>" ><i class="icon-plus"> </i> Distribute</a> </td>
                 
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                   <tr><td colspan='4'><em>No Data</em></td></tr>
                  <?php endif; ?>
                  
                 
                </tbody>
              </table>
            </div>
            <!-- /widget-content --> 
        </div>        
        </div>

        <!-- Request -->
        <div class="span8">
        <?php $__currentLoopData = $dataDistribution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $RecordBranch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="widget widget-table action-table">
            <div class="widget-header"> <i class="icon-th"></i>
              <h3>Distribution Record for 
             
                <?php echo e($RecordBranch->branch->branch_name); ?>

             
              </h3>
              <div style="float:right; padding-right:10px;"></div>
            </div>
            
            <!-- /widget-header -->
            <div class="widget-content" style="padding:20px 30px;">
            <h3 style="padding-bottom:20px;">DR #: <?php echo e($distributionnumber); ?></h3>
            <table class="table table-striped table-bordered" >
                <thead>
                  <tr>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>

                  <?php $__empty_1 = true; $__currentLoopData = $dataDistributionRecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                 
                    <td><?php echo e($Record->product->product_name); ?></td>
                    <td><em class="productprice"><?php echo e($Record->quantity); ?></em>  </td>
                    <?php if($RecordBranch->status != 1): ?>
                    <td style="width:100px;" class="td-actions"><a href="javascript:;" class="delete-modal btn btn-mini btn-danger" data-id="<?php echo e($Record->id); ?>" ><i class="icon-minus"> </i>Remove</a> </td>
                    <?php else: ?>
                    <td></td>
                    <?php endif; ?> 

                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                   <tr><td colspan='4'><em>No Data</em></td></tr>
                  <?php endif; ?>
                  
                 
                </tbody>
              </table>
              <div style="text-align:right; padding-top:20px;"><a href="javascript:;" class="generate-modal btn btn-mini btn-success" data-distributionnumber="<?php echo e($distributionnumber); ?>"><i class="icon-save"> </i>Process Delivery</a></div>
            </div>
            <!-- /widget-content --> 
        </div>        
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <!-- /row --> 
 
    </div>
    <!-- /container --> 
  </div>
  <!-- /main-inner --> 
</div>
<div id="myModal" class="modal fade" role="dialog">
  		<div class="modal-dialog">
  			<!-- Modal content-->
  			<div class="modal-content">
  				<div class="modal-header">
  					<button type="button" class="close" data-dismiss="modal">&times;</button>
  					<h4 class="modal-title"></h4>
  				</div>
  				<div class="modal-body">
  					<form class="form-horizontal" role="form">
                      <?php echo e(csrf_field()); ?>

  								<input type="hidden" class="form-control" id="fid" disabled>
                                <input type="hidden" class="form-control" id="adddistributionnumber" name="adddistributionnumber" value="<?php echo e($distributionnumber); ?>">
                                <input type="hidden" class="form-control" id="addbranchid" name="addbranchid" value="<?php $__currentLoopData = $dataDistribution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $RecordBranch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($RecordBranch->branchid); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
                                <input type="hidden" class="form-control" id="adddistributionnumberdate" name="adddistributionnumberdate" value="<?php echo date('m/d/Y'); ?>">
  						<div class="form-group">
                            <label class="control-label col-sm-2" for="quantity" >Distribution Quantity:</label>
  							<div class="col-sm-10">
  								<input type="number" class="form-control" id="quantity" name="quantity">
                            </div>
                        </div>
  					</form>
  					<div class="deleteContent">
  						Are you sure you want to remove this Distribution Record <span class="dname"></span> ? <span
  							class="hidden did"></span>
  					</div>
                    <div class="generateContent">
  						Are you sure you want to generate this request order <span class="dname"></span> ? <span
  							class="hidden distributionnumber"></span>
  					</div>
  					<div class="modal-footer">
  						<button type="button" class="btn actionBtn" data-dismiss="modal">
  							<span id="footer_action_button" class='glyphicon'> </span>
  						</button>
  					</div>
  				</div>
  			</div>
		  </div>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
    </div>
    <div id="CartInfo" class="modal fade" role="dialog">
  		<div class="modal-dialog">
  			<!-- Modal content-->
  			<div class="modal-content">
  				<div class="modal-header">
          <h4 class="modal-title" align="left"></h4>
  					<button type="button" class="close" data-dismiss="modal">&times;</button>
  					
  				</div>
  				<div class="modal-body">
  					<p>Stock Request Successfully Added!</p>
  					<div class="modal-footer">
              <button type="button" class="btn btn-warning" data-dismiss="modal">
  							<span class='glyphicon glyphicon-remove'></span> Close
  						</button>
  					</div>
  				</div>
  			</div>
		  </div>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
</div>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/distributionscript.js')); ?>"></script>
<!-- /main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('accounting.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>