
<?php $__env->startSection('content'); ?>
 <div class="main">
  <div class="main-inner">
    <div class="container">
      <div class="row">
        <div class="span12">
       
        <div class="widget widget-table action-table">
        <div class="widget-header"> <i class="icon-th-list"></i>
        <h3>Product List</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
            <div class="input-append" style="padding:20px;">
                <input class="span3 m-wrap" id="appendedInputButton" type="text" placeholder="Search Product">
                
                <button class="btn" type="button" style=" position: relative;top: -5px;">Go!</button>
            </div>
              <table class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>  </th>
                    <th>Product Name</th>
                    <th>SKU</th>
                    <th>Price</th>
                    <th>Categories</th>
                    <th>Tags</th>
                    <th>Quantity</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                  <td align="center" style="text-align:center"> <a href="#" class="avatar"><img src="<?php echo e(asset('img/message_avatar1.png')); ?>"/> </a> </td>
                    <td> <a class="name">Product Name</a></td>
                    <td>0001-1</td>
                    <td>300 php</td>
                    <td>Motor Parts, Oil</td>
                    <td>motor, parts </td>
                    <td>100</td>
                    <td class="td-actions"><a href="javascript:;" class="btn btn-small btn-success"><i class="btn-icon-only icon-ok"> </i></a><a href="javascript:;" class="btn btn-danger btn-small"><i class="btn-icon-only icon-remove"> </i></a></td>
                    
                   </tr>
                   <tr>
                  <td align="center" style="text-align:center"> <a href="#" class="avatar"><img src="<?php echo e(asset('img/message_avatar1.png')); ?>"/> </a> </td>
                    <td> <a class="name">Product Name</a></td>
                    <td>0001-1</td>
                    <td>300 php</td>
                    <td>Motor Parts, Oil</td>
                    <td>motor, parts </td>
                    <td>100</td>
                    <td class="td-actions"><a href="javascript:;" class="btn btn-small btn-success"><i class="btn-icon-only icon-ok"> </i></a><a href="javascript:;" class="btn btn-danger btn-small"><i class="btn-icon-only icon-remove"> </i></a></td>
                    
                   </tr>
                   <tr>
                  <td align="center" style="text-align:center"> <a href="#" class="avatar"><img src="<?php echo e(asset('img/message_avatar1.png')); ?>"/> </a> </td>
                    <td> <a class="name">Product Name</a></td>
                    <td>0001-1</td>
                    <td>300 php</td>
                    <td>Motor Parts, Oil</td>
                    <td>motor, parts </td>
                    <td>100</td>
                    <td class="td-actions"><a href="javascript:;" class="btn btn-small btn-success"><i class="btn-icon-only icon-ok"> </i></a><a href="javascript:;" class="btn btn-danger btn-small"><i class="btn-icon-only icon-remove"> </i></a></td>
                    
                   </tr>
                   <tr>
                  <td align="center" style="text-align:center"> <a href="#" class="avatar"><img src="<?php echo e(asset('img/message_avatar1.png')); ?>"/> </a> </td>
                    <td> <a class="name">Product Name</a></td>
                    <td>0001-1</td>
                    <td>300 php</td>
                    <td>Motor Parts, Oil</td>
                    <td>motor, parts </td>
                    <td>100</td>
                    <td class="td-actions"><a href="javascript:;" class="btn btn-small btn-success"><i class="btn-icon-only icon-ok"> </i></a><a href="javascript:;" class="btn btn-danger btn-small"><i class="btn-icon-only icon-remove"> </i></a></td>
                    
                   </tr>
                   <tr>
                  <td align="center" style="text-align:center"> <a href="#" class="avatar"><img src="<?php echo e(asset('img/message_avatar1.png')); ?>"/> </a> </td>
                    <td> <a class="name">Product Name</a></td>
                    <td>0001-1</td>
                    <td>300 php</td>
                    <td>Motor Parts, Oil</td>
                    <td>motor, parts </td>
                    <td>100</td>
                    <td class="td-actions"><a href="javascript:;" class="btn btn-small btn-success"><i class="btn-icon-only icon-ok"> </i></a><a href="javascript:;" class="btn btn-danger btn-small"><i class="btn-icon-only icon-remove"> </i></a></td>
                    
                   </tr>
                   <tr>
                  <td align="center" style="text-align:center"> <a href="#" class="avatar"><img src="<?php echo e(asset('img/message_avatar1.png')); ?>"/> </a> </td>
                    <td> <a class="name">Product Name</a></td>
                    <td>0001-1</td>
                    <td>300 php</td>
                    <td>Motor Parts, Oil</td>
                    <td>motor, parts </td>
                    <td>100</td>
                    <td class="td-actions"><a href="javascript:;" class="btn btn-small btn-success"><i class="btn-icon-only icon-ok"> </i></a><a href="javascript:;" class="btn btn-danger btn-small"><i class="btn-icon-only icon-remove"> </i></a></td>
                    
                   </tr>
                
                
                </tbody>
              </table>
            </div>
            <!-- /widget-content --> 
          </div>            

       

</div>
        <!-- /span4 --> 
       
      </div>
      <!-- /row --> 
      <div class="row">
	      	
	      	<div class="span12">
              <div class="widget-header">
						<i class="icon-star"></i>
						<h3>Daily Sales Summary Report</h3>
					</div>
	      	<div class="info-box">
               <div class="row-fluid stats-box">
                   
                  <div class="span4">
                  	<div class="stats-box-title">Branch 1</div>
                    <div class="stats-box-all-info"><i class="icon-money" style="color:#3366cc;"></i> 555K</div>
                    
                  </div>
                  
                  <div class="span4">
                    <div class="stats-box-title">Branch 2</div>
                    <div class="stats-box-all-info"><i class="icon-money" style="color:#F30"></i> 66.66</div>
                   
                  </div>
                  
                  <div class="span4">
                    <div class="stats-box-title">Total Sales</div>
                    <div class="stats-box-all-info"><i class="icon-money" style="color:#3C3"></i> 15.55</div>
                    
                  </div>
               </div>
               
               
             </div>
               
               
         </div>
         </div>
    <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /main-inner --> 
</div>
<!-- /main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cashier.layouts.cashier', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>