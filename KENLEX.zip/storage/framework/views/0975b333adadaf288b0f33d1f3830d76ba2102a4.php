

<?php $__env->startSection('content'); ?>
<div class="container">

      <div class="row" style="padding-top:50px; padding-bottom:100px;">

        <div class="col-lg-3">
          <?php echo $__env->make('includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         

        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9">
        <?php $__currentLoopData = $dataProductquantity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Productquantity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">

            <div class="col-md-8">
            <img class="img-fluid" src="<?php echo e(asset('productimg')); ?>/<?php echo e($Productquantity->pic); ?>" alt="">
            </div>

            <div class="col-md-4">
            <h3 class="my-3"><?php echo e($Productquantity->product->product_name); ?></h3>
            <p><?php echo e($Productquantity->description); ?></p>
            <h3 class="my-3">Product Details</h3>
            <ul>
                <li>Availability : <?php echo e($Productquantity->quantity); ?> <?php echo e($Productquantity->unit); ?></li>
                <li>Category: <a href="/category/<?php echo e($Productquantity->category_id); ?>" class="name"><?php echo e($Productquantity->category->cat_name); ?></a></li>
                <li>Price:  &#8369; <?php echo e($Productquantity->price); ?></li>
                <li>Width: <?php echo e($Productquantity->width); ?></li>
                <li>Height: <?php echo e($Productquantity->height); ?></li>
                <li>Weight: <?php echo e($Productquantity->weight); ?></li>
                <li>Lenght: <?php echo e($Productquantity->lenght); ?></li>
            </ul>
            <h5 class="my-3">Tags</h5>
            <?php $__currentLoopData = $Productquantity->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/tags/<?php echo e($tag->slug); ?>"><label class="label label-info"><?php echo e($tag->name); ?></label></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <br />
                <a href="javascript:;" class="edit-modal btn btn-warning" data-pic="<?php echo e($Productquantity->pic); ?>" data-amount="<?php echo e($Productquantity->price); ?>.00" data-name="<?php echo e($Productquantity->product->product_name); ?>" data-id="<?php echo e($Productquantity->id); ?>" ><i class="icon-shopping-cart"> </i><span style="color:#fff;">Add to Cart</span></a>
            
            </div>
            
        </div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- /.col-lg-9 -->

      </div>
      <!-- /.row -->

    </div>

    <div id="myModal" class="modal fade" role="dialog">
  		<div class="modal-dialog">
  			<!-- Modal content-->
  			<div class="modal-content">
  				<div class="modal-header">
          <h4 class="modal-title" align="left"></h4>
  					<button type="button" class="close" data-dismiss="modal">&times;</button>
  					
  				</div>
  				<div class="modal-body">
  					<form class="form-horizontal" role="form">
                      <?php echo e(csrf_field()); ?>

  						<div class="form-group row">
  							<div class="col-sm-3">
                  <img src="" alt="product image" id="productimg" width="100">
  								<input type="hidden" class="form-control" id="fid" disabled>
                  <input type="hidden" class="form-control" id="amount" disabled>
  							</div>
                <div class="col-sm-8">
                  <p><strong>Product Name: </strong><span id="productedit_name"></p>
                  <p ><strong>Amount: </strong> &#8369; <span id="productamount"></span></p>
                  <strong>Quantity:</strong>
  
  								<input type="number" class="form-control" id="quantity" name="quantity">
  						
  								<!-- <input type="text" class="form-control" id="productedit_name" name="productedit_name"> -->
  							</div>
  						</div>
            
  					</form>
  					<div class="modal-footer">
  						<button type="button" class="btn actionBtn" data-dismiss="modal">
  							<span id="footer_action_button" class='glyphicon'> </span>
  						</button>
  						
  					</div>
  				</div>
  			</div>
		  </div>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
    </div>
<div id="CartInfo" class="modal fade" role="dialog">
  		<div class="modal-dialog">
  			<!-- Modal content-->
  			<div class="modal-content">
  				<div class="modal-header">
                    <h4 class="modal-title" align="left"></h4>
  					<button type="button" class="close" data-dismiss="modal">&times;</button>
  					
  				</div>
  				<div class="modal-body">
  					<p>Product Successfully Added to the Cart!</p>
  					<div class="modal-footer">
                            <button type="button" class="btn btn-warning" data-dismiss="modal">
  							    <span class='glyphicon glyphicon-remove'></span> Close
  						    </button>
  					</div>
  				</div>
  			</div>
		</div>
    </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
    </div>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/cartscript.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appv2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>