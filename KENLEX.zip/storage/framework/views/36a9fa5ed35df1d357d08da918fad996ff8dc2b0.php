<?php $__env->startSection('content'); ?>
 <div class="main">
  <div class="main-inner">
    <div class="container">
      <div class="row">
      <div class="span4 noprint">
      <div class="widget widget-table action-table noprint">
            <div class="widget-header"> <i class="icon-th-list"></i>
              <h3>Generate Report</h3>
            </div>
                <div class="widget-content">
                    <div class="box box-info">
                        <div class="box-header">
                            <i class="fa fa-envelope"></i>
                            <h3 class="box-title"></h3>
                        </div>
                        <form action="/admin/report/generate" method="post">
                        <?php echo e(csrf_field()); ?>   
                        <div class="box-body">
                                <div class="form-group">
                                <label for="">From: </label>
                                    <input type="date" class="form-control" name="from" required/>
                                </div>
                                <div class="form-group">
                                <label for="">To: </label>
                                    <input type="date" class="form-control" name="to" required/>
                                </div>
                        </div>
                        <div class="" style="padding:20px;">
                            <button type="submit" class="pull-right btn btn-default" id="sendEmail">Generate Report <i class="fa fa-arrow-circle-right"></i></button>
                        </div>
                        </form>
                    </div> 
                    
                </div>
                
            </div>
            <div class="widget-content">
            <div class="box-header">
                            <i class="fa fa-envelope"></i>
                            <h3 class="box-title">Report by Branch</h3>
                        </div>
                <div class="shortcuts"> 
                <?php $__currentLoopData = $dataBranch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                <a href="/admin/report/branch/<?php echo e($Branch->id); ?>" class="shortcut"><i class="shortcut-icon icon-sitemap"></i><span class="shortcut-label"><?php echo e($Branch->branch_name); ?></span> </a>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                </div>
              <!-- /shortcuts --> 
            </div>
        </div>
      <div class="span8">
       
       <div class="widget widget-table action-table">
       <div class="widget-header"> <i class="icon-th-list"></i>
       <h3>Out of Stocks Report</h3>
           </div>
           <!-- /widget-header -->
           <div class="widget-content">
           <table class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>  </th>
                    <th>Product Name</th>
                    <th>Branch </th>
                    <th>Quantity</th>
      
                  </tr>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $dataProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                  <td align="center" style="text-align:center"> <a href="#" class="avatar"><img src="<?php echo e(asset('productimg')); ?>/<?php echo e($Product->pic); ?>" width="100px"/> </a> </td>
                    <td> <a class="name"><?php echo e($Product->product->product_name); ?></a></td>
                    <td><em class="productprice"><?php echo e($Product->branch->branch_name); ?></em>  </td>
                    <td><em class="productprice"><?php echo e($Product->quantity); ?></em>  </td>
                  
                    
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                   <tr><td colspan='3'><em>No Data</em></td></tr>
                  <?php endif; ?>
                  <tr>
                    <td colspan="5">
                    <button class="btn btn-primary hidden-print noprint" align="right" onclick="myFunction()"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Print</button>
                    <script>
                    function myFunction() {
                    window.print();}
                    </script>
                    </td>
                </tr>
                 
                </tbody>
              </table>
           </div>
           
           <!-- /widget-content --> 
         </div>            

      

</div>
        <!-- /span4 --> 
       
      </div>
      <!-- /row --> 
      <div class="row noprint">
	      	
	      	<div class="span12">
              <div class="widget-header">
						<i class="icon-star"></i>
						<h3>Daily Sales Summary Report</h3>
					</div>
	      	<div class="info-box">
               <div class="row-fluid stats-box">
                   
                  <div class="span4">
                  	<div class="stats-box-title">Today's Sale</div>
                    <div class="stats-box-all-info"><i class="icon-money" style="color:#3366cc;"></i><?php echo e(number_format($DailySales,2)); ?></div>
                    
                  </div>
                  
                  <div class="span4">
                    <div class="stats-box-title">Total Sales</div>
                    <div class="stats-box-all-info"><i class="icon-money" style="color:#3C3"></i><?php echo e(number_format($TotalSales,2)); ?></div>
                    
                  </div>
               </div>
               
               
             </div>
               
               
         </div>
         </div>
    <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /main-inner --> 
</div>
<!-- /main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>