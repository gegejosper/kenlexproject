

<?php $__env->startSection('content'); ?>
<div class="container">

      <div class="row"  style="padding-top:50px;">

        <div class="col-lg-3">
          <?php echo $__env->make('includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         

        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9">

          <div class="row" >
          <?php echo $__env->make('includes.product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </div>
          <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

      </div>
      <!-- /.row -->

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appv2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>