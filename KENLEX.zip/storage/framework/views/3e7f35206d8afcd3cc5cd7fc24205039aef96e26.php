<?php $__env->startSection('content'); ?>
<header class="bg-header text-white">
      <div class="container text-center">
        <h1>About Us</h1>
        <p class="lead">This is a great place to talk about your webpage. This template is purposefully unstyled so you can use it as a boilerplate or starting point for you own landing page designs! This template features:</p>
      </div>
      <div class="container" style="max-width:800px; margin:0 auto; padding-top:30px;">
        <ul>
              <li>Clickable nav links that smooth scroll to page sections</li>
              <li>Responsive behavior when clicking nav links perfect for a one page website</li>
              <li>Bootstrap's scrollspy feature which highlights which section of the page you're on in the navbar</li>
              <li>Minimal custom CSS so you are free to explore your own unique design options</li>
            </ul>
      </div>
    </header>
<section id="services">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 mx-auto">
            <h2 class="text-center">SERVICES</h2>
            <p class="lead  text-center"> Philip Motor Parts & Accessories also offered:</p>
            <ul>
              <li>Overhauling , any kind of motorcycle.</li>
              <li>Change Oil on your motorcycle.</li>
              <li>Wirings</li>
              <li>Repair’s all parts in your motorcycle.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <section id="contact" class="bg-contact">
      <div class="container ">
        <div class="row">
          <div class="col-lg-8 mx-auto">
            <h2 class="text-center"  style="color:#fff">Contact Us</h2>
            <p class="lead text-center" style="color:#fff"> Philip Motor Parts & Accessories can be reached through there address, located at Barangay San Jose Aurora Zamboanga del Sur beside Transcycle at Archie Yongco’s building.

</p>
            
          </div>
        </div>
      </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appv2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>