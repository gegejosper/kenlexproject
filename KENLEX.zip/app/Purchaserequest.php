<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Purchaserequest extends Model
{
    //
}
