<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cashierorder extends Model
{
    //
}
