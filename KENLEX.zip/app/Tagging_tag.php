<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tagging_tag extends Model
{
    //
}
