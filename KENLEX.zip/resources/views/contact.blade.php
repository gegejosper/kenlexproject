@extends('layouts.front')

@section('content')
  <main id="main">
  </main>
@endsection
